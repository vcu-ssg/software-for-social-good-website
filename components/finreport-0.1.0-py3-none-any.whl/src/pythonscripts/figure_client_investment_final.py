import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.ticker as mtick
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd 
import seaborn as sns
import textwrap
#import os
#import csv

sns.set_theme()    

#standand normal random sample for monthly cash flow
#For random samples from N(mu, sigma^2), use: sigma * np.random.randn(...) + mu
mthly = 30000 * np.random.randn(106) + 12000
#remember to convert lists to numpy arrays
mthly = np.array(mthly)
#set x axis as range of y values
x = range(len(mthly))
x = np.array(x)

#example date range
date_range = ['10/1/2013', '4/1/2014','10/1/2014', '4/1/2015',
                       '10/1/2015', '4/1/2016','10/1/2016', '4/1/2017',
                       '10/1/2017', '4/1/2018','10/1/2018', '4/1/2019',
                       '10/1/2019', '4/1/2020','10/1/2020', '4/1/2021',
                       '10/1/2021', '4/1/2022']

#calc cumulative growth as principle (5 mil) plus each month
growth = 5000000 + mthly[0]
cum_list = [growth]
for val in mthly[1:]:
    growth += val
    cum_list.append(growth)
cumulative = np.array(cum_list)

bar_colors = np.where(mthly >= 0, 'g', 'r')

#matplotstuff goes below

#Add figure
fig = plt.figure(figsize=(10,5))

#divide figure into 3 rows and columns
gs = GridSpec(3, 3, width_ratios=[1, 1, 1], height_ratios=[.25, .25, .25], wspace=1.2, figure=fig)

#bar/line chart takes up first two columns
ax = fig.add_subplot(gs[0:, :-1])

# Shrink the size of the axes object and change coordinates on figure (need to do this for both axes)
box = ax.get_position()
ax.set_position([box.x0 + .02, box.y0 + .1, box.width, box.height * 0.8])

ax.set_title("Growth of $5,000,000 (10/31/2013 - 8/31/2022)")

#set line/cumulative y axis according to png
ax.set_ylim(0, 7000000)

graph1 = sns.lineplot(x=x, y=cumulative, color = 'b', ax=ax)

#insert corresponding y axis for bar chart
ax2 = plt.twinx()

box2 = ax2.get_position()
ax2.set_position([box2.x0 + .02, box2.y0 + .1, box2.width, box2.height * 0.8])

#set bar/monthly y axis according to png
ax2.set_ylim(-200000, 250000)

graph2 = sns.barplot(x=x, y=mthly, ax=ax2, palette=bar_colors)

#rotate the tick labels by 45 degrees
ax.set_xticks(np.linspace(0, len(x), len(date_range)), date_range)
ax.set_xticklabels(date_range, rotation = 90)

#set y grid to monthly growth (ax2)
ax2.grid(axis = 'y')

#format y axes
ax.ticklabel_format(axis='y', style='plain')

fmt = '${x:,.0f}'
tick = mtick.StrMethodFormatter(fmt)
ax.yaxis.set_major_formatter(tick)
ax2.yaxis.set_major_formatter(tick)

# Remove tick marks on y-axis labels
ax.tick_params(axis="y", which="both", length=0, width=0)
ax2.tick_params(axis="y", which="both", length=0, width=0)

#get rid of plot axis and outlines
ax.spines['top'].set_color('none')
ax.spines['bottom'].set_color('none')
ax.spines['left'].set_color('none')
ax.spines['right'].set_color('none')
ax.set_ylabel("Notional Value")
ax2.spines['top'].set_color('none')
ax2.spines['bottom'].set_color('none')
ax2.spines['left'].set_color('none')
ax2.spines['right'].set_color('none')
ax2.set_ylabel("Monthly Cash Flow")

annotations = fig.add_subplot(gs[0:, -1])

#get rid of plot axis and outlines
annotations.get_yaxis().set_visible( False )
annotations.get_xaxis().set_visible( False )
annotations.spines['top'].set_color('none')
annotations.spines['bottom'].set_color('none')
annotations.spines['left'].set_color('none')
annotations.spines['right'].set_color('none')
annotations.axes.get_xaxis().get_label().set_visible( False )


t1_input = 'Beginning Strategy Investment:    \n$5,000,000'
t2_input = 'Management Fees:\n0.50% Annual (charged quarterly)'
t3_input = '''New Cash Flow:
$822,205\n
Average Annual Cash Flow:         
$7,757 (2.56%)'''
t4_input = 'Ending Investment Balance:        \n$5,822,205'

#wrap text after 20 (width = x) characters
#t1_wrapped = textwrap.fill(t1_input, width = 20)

annotations.text(-.25, .85, t1_input,
        horizontalalignment='left',
        verticalalignment='center', color='black', bbox=dict(boxstyle="square,pad=0.3",fc="white", ec="#263759", lw=1))

annotations.text(-.25, .7, t2_input,
        horizontalalignment='left',
        verticalalignment='center', color='black', bbox=dict(boxstyle="square,pad=0.3",fc="white", ec="#263759", lw=1))

annotations.text(-.25, .4, t3_input,
        horizontalalignment='left',
        verticalalignment='center', color='orange', bbox=dict(boxstyle="square,pad=0.3",fc="white", ec="#263759", lw=1))

annotations.text(-.25, .17, t4_input,
        horizontalalignment='left',
        verticalalignment='center', color='blue', bbox=dict(boxstyle="square,pad=0.3",fc="white", ec="#263759", lw=1))

plt.show()

"""to do:
1. add second y axis label --> DONE
2. add line graph for cumulative notional growth --> DONE
    for this example, just add values from "mthly" aka mthly cash flow to 5 mil for each month
3. add annotations on the right side
other stuff:
4. color code positive and negative values"""