import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import argparse


def main(initial_investment):
    overlayclientinvestmentamount = initial_investment


    PlotTitleFont = {'family':'Century Schoolbook','color':'black','size':20}
    BodyFont = {'family':'Montserrat','color':'#5D6B49','size':12}
    LabelFont = {'family':'Montserrat','color':'#5D6B49','size':9}
    PlotLegendFont = {'family':'Montserrat','color':'#5D6B49','size':12}

    ## Source data from proposal figure.
    data = {
    'X':[5,10,15,20,25],
    'Standard': [1402552,1967151,2759032,3869684,5427433],
    'Overlay' : [1538624,2367364,3642482,5604411,8623081]
    }

    df = pd.DataFrame(data)

    ratios = df
    ratios["Standard"] = (ratios["Standard"]+5000000) / 5000000
    ratios["Overlay"] = (ratios["Overlay"]+5000000) / 5000000

    df2 = ratios
    df2["Standard"] = (ratios["Standard"] * overlayclientinvestmentamount) - overlayclientinvestmentamount
    df2["Overlay"] = (ratios["Overlay"] * overlayclientinvestmentamount)  - overlayclientinvestmentamount

    # create initial plot
    ax = df2.plot(x="X", y=["Standard", "Overlay"], kind="bar", rot=0, color=["#263759","#4E9DC3"], width=0.5)

    # set title, legend and ticks
    ax.set_title("Potential Impact of Overlay on a ${:,.1f}M Portfolio".format( overlayclientinvestmentamount / 1000000 ),fontdict=PlotTitleFont)
    ax.legend( loc="upper left" )
    ax.set_xticklabels(['5 years','10 Years','15 Years','20 Years','25 Years'])
    ax.legend(['Standard Portfolio Returns at 7%','Portfolio Returns + Overlay* at 9%'])

    # add space between the bars by shifting the individual bar pairs left and right
    for id,x in enumerate(ax.containers[0].patches):
        ax.containers[0].patches[id].xy = (x.xy[0]-0.025,x.xy[1])

    for id,x in enumerate(ax.containers[1].patches):
        ax.containers[1].patches[id].xy = (x.xy[0]+0.025,x.xy[1])

    # Add bar labels
    ax.bar_label(ax.containers[0], labels=[ "${:,.2f}M".format(x) for x in round(df2["Standard"]/1000000,3)], color='#5D6B49' )
    ax.bar_label(ax.containers[1], labels=[ "${:,.2f}M".format(x) for x in round(df2["Overlay"]/1000000,3)], color='#5D6B49' )

    # turn off lines around chart
    ax.spines["top"].set_visible( False )
    ax.spines["left"].set_visible( False )
    ax.spines["right"].set_visible( False )

    # turn off x and y labels; y axis, legend frame
    ax.get_yaxis().set_visible( False )
    ax.axes.get_xaxis().get_label().set_visible( False )
    ax.get_legend().set_frame_on( False );


    # shrinking axis height

    #create annotation data
    df3 = df.assign(Difference = df['Overlay'] - df['Standard'], Percentage = df['Overlay'] / df['Standard'] - 1)


    #df3.assign(percentage = df['Overlay'] / df['Standard'] - 1)

    #for xi, yi, diff in zip(df3['X'], df2['Overlay'], df3['Difference']):
    #    ax.annotate(diff, xy= (xi, yi), xytext=(1, 1))



    #zip puts concurent objects into tuples
    for index, values in enumerate(zip(df3['Difference'], df3['Percentage'])):
        if index == 4:
            #if the bar extends above the title, wrap the annonotation down and left
            plt.text(index - 1, df2['Overlay'].iat[index] - 100000, "+${:,.0f}\n   +{:,.1f}%".format(values[0], values[1] * 100), c = "#4E9DC3", bbox=dict(boxstyle="square,pad=0.3",
                        fc="white", ec="#263759", lw=2))
        else:
            plt.text(index - 0.15, df2['Overlay'].iat[index] +150000, "+${:,.0f}\n   +{:,.1f}%".format(values[0], values[1] * 100), c = "#4E9DC3", bbox=dict(boxstyle="square,pad=0.3",
                        fc="white", ec="#263759", lw=2))

    plt.show()

'''Some things to change:
1. Change the Y axis on plt.text to a ratio
2. Figure out how the finance formulas work - rn just using ratios via the numbers they gave to us
3. Shrink the size of title a little'''

"""if label/annotation is above certain y axis point on the grid - move it down"""

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('initial_investment', type=float, help='Initial investment amount')
    args = parser.parse_args()

    main(args.initial_investment)