import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.ticker as mtick
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd
import textwrap
from palettable.cartocolors.sequential import Teal_7

fig = plt.figure()

#add in pie graph labels and ensure text wrapping
pie_labels = ['Bonds', 'US Large Cap Equity', 'International Equity', 'US Small Cap Equity']
pie_labels = [textwrap.fill(x, width = 13) for x in pie_labels]
#add a color map for pie charts
cmap = plt.get_cmap(Teal_7.mpl_colormap)
pie_colors = cmap(np.linspace(1,0,len(pie_labels)))

bar_colors = ["#ABAFB4","#263759"]

pie_sizes = [40, 35, 15, 10]

xlabel = ['Balanced', textwrap.fill('Balanced with Overlay', width = 10)]
ann_returns = [8.72, 11.03]
ann_yield = [2.03, 5.47]
sharpe = [0.96, 0.98]

pie_plot = plt.subplot(221)
pie_plot.set_title('Balanced Portfolio (60%\nstocks / 40% bonds)')
pie2_plot = plt.subplot(222)
pie2_plot.set_title('Balanced Portfolio with\n Overlay (60% stocks / 40% \nbonds)')




#assign plot location and hide y axis
ann_ret = plt.subplot(337)
ann_ret.get_yaxis().set_visible( False )
# set the font properties for the x-axis tick labels
ann_ret.set_xticklabels(xlabel, fontfamily='Montserrat', fontsize=7, color='#5D6B49')
# turn off lines around chart
ann_ret.spines["top"].set_visible( False )
ann_ret.spines["left"].set_visible( False )
ann_ret.spines["right"].set_visible( False )
#remove tick marks on x axis
ann_ret.tick_params(axis="x", which="both", length=0, width=0)
#set title
ann_ret.set_title('Annualized\nReturns', fontsize=10, y=.95)

#assign plot location and hide y axis
ann_dis_yld = plt.subplot(338)
ann_dis_yld.get_yaxis().set_visible( False )
# set the font properties for the x-axis tick labels
ann_dis_yld.set_xticklabels(xlabel, fontfamily='Montserrat', fontsize=7, color='#5D6B49')
# turn off lines around chart
ann_dis_yld.spines["top"].set_visible( False )
ann_dis_yld.spines["left"].set_visible( False )
ann_dis_yld.spines["right"].set_visible( False )
#remove tick marks on x axis
ann_dis_yld.tick_params(axis="x", which="both", length=0, width=0)
#set title
ann_dis_yld.set_title('Annualized\nDistributed Yield', fontsize=10, y=1.05)

#assign plot location and hide y axis
sharpe_ratio = plt.subplot(339)
sharpe_ratio.get_yaxis().set_visible( False )
# set the font properties for the x-axis tick labels
sharpe_ratio.set_xticklabels(xlabel, fontfamily='Montserrat', fontsize=7, color='#5D6B49')
# turn off lines around chart
sharpe_ratio.spines["top"].set_visible( False )
sharpe_ratio.spines["left"].set_visible( False )
sharpe_ratio.spines["right"].set_visible( False )
#remove tick marks on x axis
sharpe_ratio.tick_params(axis="x", which="both", length=0, width=0)
#set title
sharpe_ratio.set_title('Risk\nEfficiency\n(Sharpe\nRatio)', fontsize=10, y=.90)

#draw out the figures
plt.setp(pie_plot.pie(pie_sizes, labels=pie_labels, startangle=310, autopct='%1.0f%%', textprops={'size':'x-small'},
                       colors=pie_colors, labeldistance=1.2, wedgeprops={"linewidth": 1, "edgecolor": "white"})[1], fontsize=8)

plt.setp(pie2_plot.pie(pie_sizes, labels=pie_labels, startangle=310, autopct='%1.0f%%', textprops={'size':'x-small'},
                        colors=pie_colors, labeldistance=1.2, wedgeprops={"linewidth": 1, "edgecolor": "white"}, hatch='.......')[1], fontsize=8)


ann_ret.bar(xlabel, ann_returns, color=bar_colors, width=.3)
# add labels to the bars
for i, v in enumerate(ann_returns):
    ann_ret.text(i-.18, v + 0.5, str(v))

ann_dis_yld.bar(xlabel, ann_yield, color=bar_colors, width=.3)
# add labels to the bars
for i, v in enumerate(ann_yield):
    ann_dis_yld.text(i-.18, v + .20, str(v))

sharpe_ratio.bar(xlabel, sharpe, color=bar_colors,width=.3)
# add labels to the bars
for i, v in enumerate(sharpe):
    sharpe_ratio.text(i-.18, v + 0.05, str(v))

plt.show()