import matplotlib.pyplot as plt
import yahoo_fin.stock_info as si
import numpy as np
import pandas as pd
import datetime

ticker_dict = {
    1: "ovl",
    2: "ovs",
    3: "ovf",
    4: "ovlh",
    5: "ovb",
    6: "ovt",
    7: "ovm",
}

user_input = int(
    input(
        """Enter the number corresponding to the desired data frame: \n
                        1: Overlay Shares Large Cap Equity ETF \n
                        2: Overlay Shares Small Cap Equity ETF \n
                        3: Overlay Shares Foreign Equity ETF \n
                        4: Hedged Large Cap Equity ETF \n
                        5: Overlay Shares Core Bond ETF \n
                        6: Overlay Shares Short Term Bond ETF \n
                        7: Overlay Shares Municipal Bond ETF \n
                        """
    )
)

ticker = ticker_dict[user_input]

position_size = float(input("Enter the position size: "))

try:
    end_date = datetime.datetime.now().strftime("%Y-%m-%d")
    result = si.get_data(ticker)
    print(result)
except AssertionError as e:
    print("Error: {}".format(str(e)))

if result is not None:
    # Calculate the performance
    result["performance"] = result["close"] * position_size

    # Plot the performance
    ax = result["performance"].plot(title=f"Performance of {ticker} to {end_date}")
    ax.set_ylabel("Position Value ($)") 
    plt.show()
else:
    print("No data available to plot.")
