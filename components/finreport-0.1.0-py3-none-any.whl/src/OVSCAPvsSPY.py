import matplotlib.pyplot as plt
import yahoo_fin.stock_info as si
import numpy as np
import pandas as pd
import datetime

initial_investment = 100000

ticker_dict = {
    1: "ovl",
    2: "ovs",
    3: "ovf",
    4: "ovlh",
    5: "ovb",
    6: "ovt",
    7: "ovm",
}
ticker = ticker_dict[2]

position_size = float(initial_investment)

try:
    end_date = datetime.datetime.now().strftime("%Y-%m-%d")
    result = si.get_data(ticker)
    print(result)
except AssertionError as e:
    print("Error: {}".format(str(e)))

if result is not None:
    # Calculate the performance
    result["performance"] = result["close"] * position_size

    # Plot the performance
    ax = result["performance"].plot(title=f"Performance of {ticker} to {end_date}")
    ax.set_ylabel("Position Value ($)") 
    plt.show()
else:
    print("No data available to plot.")
