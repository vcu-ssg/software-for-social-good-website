import os
import subprocess
#import quarto
from flask import Flask, request, render_template, jsonify, send_file
import sys
from pathlib import Path
import json
import frontmatter
from datetime import datetime
from loguru import logger

import pkg_resources

# Specify the name of your package
package_name = 'finreport'

# Retrieve the distribution object for your package
distribution = pkg_resources.get_distribution(package_name)

# Retrieve the path to your package's installation directory
package_path = os.path.join(distribution.location,"src" )

# Use the package_path to access the package files

# Rest of the app.py code
#learn to cleanse string inputs for hardening

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=["POST"])
def calculate():
    def fresh_qmd(fm, partner_name, client_name, advisor_name, initlal_investment):
            
            os.chdir( package_path )

            #create needed names and value
            current_timestamp = datetime.now()
            datestamp = current_timestamp.strftime("%Y-%m-%d")
            logger.info("logged date")
            logger.info(partner_name)
            stripped_partner = partner_name.replace(" ", "")
            logger.info("logged partner")
            stripped_client = client_name.replace(" ", "")
            logger.info("logged client")
            stripped_advisor = advisor_name.replace(" ", "")
            logger.info("logged advisor")
            filename = "-".join([stripped_partner, stripped_advisor, stripped_client, datestamp, "overlay.qmd"])
            logger.info("logged union")
            
            # Modify the YAML header with environment variables from frontmatter
            fm["partner_name"] = partner_name
            fm["client_name"] = client_name
            fm["author"] = advisor_name
            fm["1000000"] = initial_investment
            fm["format"]["pptx"]["reference-doc"] = stripped_partner + "-template.pptx"
            fm["date"] = datestamp
            #convert content to array of string
            arrayofstrings = fm.content.split("\n")
            
            #find individual lines and replace them as needed
            for i, line in enumerate(arrayofstrings):
                if "overlay_client_investment_amount" in line:
                    arrayofstrings[i] = "overlay_client_investment_amount = " + str(initial_investment)
                    break
            #rebuild content from array of string
            fm.content = "\n".join(arrayofstrings)
            
            return fm, filename
    
    try :
        
        
        
        logger.info("setting variables")
        
        initial_investment = request.form.get('initial_investment')
        client_name = request.form.get('client_name')
        advisor_name = request.form.get('advisor_name')
        partner_name = request.form.get('partner_name')
        
        logger.info(partner_name)
        
        logger.info("reading base.qmd")
        logger.info("current directory: {os.getcwd()}")
        base_file_name = os.path.join(package_path,"base.qmd")
        logger.info("base file: {base_file_name}")
        with open(base_file_name, 'r') as f:
            post = frontmatter.loads(f.read())
        logger.info("fresh_qmd call")

        (fm, filename) = fresh_qmd(post, partner_name, client_name, advisor_name, initial_investment)
        
        
        #post['advisor_name'] = initial_investment;
        
        
        ## in order to modify python parameters, post.content takes in string
        # need to parse string and set to array of strings by line and search for 
        # desired value using .join and split
        # post.content
                
        
        
        logger.info(f"generating qmd file:{filename}")
        with open(filename, "w") as f:
            f.write(frontmatter.dumps(post))
            f.close()
            
        #print(result.stderr.decode('utf-8'))

        #command = f"quarto render study4_overlay_test.qmd --initial_investment {initial_investment} --client_name {client_name}"
        #result = subprocess.run(command, shell=True, capture_output=True, text=True)
        #os.rename#rename pptx
        
        result = subprocess.run(["quarto", "render", filename])
        
        current_timestamp = datetime.now()
        datestamp = current_timestamp.strftime("%Y-%m-%d")
        stripped_partner = partner_name.replace(" ", "")
        stripped_client = client_name.replace(" ", "")
        stripped_advisor = advisor_name.replace(" ", "")
        filename = "-".join([stripped_partner, stripped_advisor, stripped_client, datestamp, "overlay.pptx"])
        logger.info(filename)
        
        return send_file(filename, as_attachment=True)
    #quarto::quarto_render(input = "template.qmd", execute_params = list(param1 = value1, param2 = value2))
        #subprocess to run quarto
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    

def finreport():
    logger.info(f"package location: {package_path}")
    app.run(host="0.0.0.0", port=8080, debug=True)

if __name__ == "__main__":
    finreport()
    